package com.example.tron.andgestion;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.example.tron.andgestion.bddlocal.client.Client;
import com.example.tron.andgestion.bddlocal.depot.Depot;
import com.example.tron.andgestion.bddlocal.facture.Facture;
import com.example.tron.andgestion.bddlocal.fonction.outils;
import com.example.tron.andgestion.bddlocal.parametre.Parametre;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    Button connexion;
    Button facture;
    TextView login;
    TextView mdp;
    ArrayList<Facture> liste_facture = new ArrayList<Facture>();
    ArrayList<Client> liste_client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connexion = (Button) findViewById(R.id.connexion_button);
        facture = (Button) findViewById(R.id.menu_facturation);
        login =(TextView) findViewById(R.id.connexion_login);
        mdp =(TextView) findViewById(R.id.connexion_mdp);
        double qte_stock = outils.articleDisponibleServeur(10313,84);
        connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ArrayList<Depot> list = outils.listeDepotServeur();
                // ! à enlever
                Parametre parametre = outils.connexion(login.getText().toString(), mdp.getText().toString());
                if(parametre != null){
                    liste_client = outils.listeClientServeur("YDE");
                    System.out.println("liste client "+liste_client.size());
                    Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                    intent.putExtra("liste_facture", liste_facture);
                    intent.putExtra("parametre", parametre);
                    intent.putExtra("liste_client", liste_client);
                    startActivity(intent);
                }
            }
        });

    }
}
