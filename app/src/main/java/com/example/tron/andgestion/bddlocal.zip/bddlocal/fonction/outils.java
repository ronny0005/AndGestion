package com.example.tron.andgestion.bddlocal.fonction;

import android.content.Context;
import android.os.StrictMode;


import com.example.tron.andgestion.bddlocal.affaire.Affaire;
import com.example.tron.andgestion.bddlocal.article.ArticleServeur;
import com.example.tron.andgestion.bddlocal.caisse.Caisse;
import com.example.tron.andgestion.bddlocal.client.Client;
import com.example.tron.andgestion.bddlocal.depot.Depot;
import com.example.tron.andgestion.bddlocal.parametre.Parametre;
import com.example.tron.andgestion.bddlocal.souche.Souche;
import com.example.tron.andgestion.bddlocal.vehicule.Vehicule;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;

/**
 * Created by T.Ron$ on 12/03/2016.
 */
public class outils {

    public static Parametre connexion(String login,String mdp){
        if(!login.isEmpty() && !mdp.isEmpty())
                return enregistrementServeur(login,mdp);
        return null;
    }

    public static String getJsonFromServer(String url) throws IOException {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        final StringBuilder sb = new StringBuilder();
        InputStream is = (InputStream) new URL(url).getContent();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String result, line = reader.readLine();
        result = line;
        while((line=reader.readLine())!=null){
            result+=line;
        }
        return result;
    }

    public static ArrayList<Depot> listeDepotServeur(){
        JSONObject json = null;
        ArrayList<Depot> ldep=null;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/depot"));
            JSONArray jArray = json.getJSONArray("data");
            ldep= new ArrayList<Depot>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                ldep.add(new Depot(json_data.getInt("DE_No"),json_data.getString("DE_Intitule")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ldep;
    }

    public static ArrayList<Depot> enregistrementServeur(String de_no,String ct_num,String co_no,String do_souche,String affaire,String num_doc,String vehicule,String user,String mdp){
        JSONObject json = null;
        ArrayList<Depot> ldep=null;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/register?DE_No="+de_no+"&CT_Num="+ct_num+"&CO_No="+co_no+"&DO_Souche="+do_souche+"&Affaire="+affaire+"&NumDoc="+num_doc+"&vehicule="+vehicule+"&NomUser="+user+"&Password="+mdp));
            JSONArray jArray = json.getJSONArray("data");
            ldep= new ArrayList<Depot>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                ldep.add(new Depot(json_data.getInt("DE_No"),json_data.getString("DE_Intitule")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ldep;
    }

    public static String msgToServer(String msg){
        Socket socket;
        BufferedReader in;
        PrintWriter out;
        try {
            socket = new Socket("192.168.1.19",2009);
            out = new PrintWriter(socket.getOutputStream());
            out.println(msg);
            out.flush();
            in = new BufferedReader (new InputStreamReader (socket.getInputStream()));
            String message_distant = in.readLine();
            System.out.println(message_distant);
            socket.close();
            return message_distant;
        }catch (UnknownHostException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static ArrayList<ArticleServeur> liste_article(){
        JSONObject json = null;
        ArrayList<ArticleServeur> lart=null;
        try {
            json = new JSONObject(msgToServer("liste_article"));
            JSONArray jArray = json.getJSONArray("data");
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new ArticleServeur(json_data.getInt("AR_Ref"),json_data.getString("AR_Design"),json_data.getDouble("AR_PrixAch"),json_data.getDouble("taxe1"),json_data.getDouble("taxe2"),json_data.getDouble("taxe3")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static ArrayList<Client> liste_client(){
        JSONObject json = null;
        ArrayList<Client> lcient= new ArrayList<Client>();
        try {
            json = new JSONObject(msgToServer("liste_client"));
            JSONArray jArray = json.getJSONArray("data");
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lcient.add(new Client(json_data.getString("CT_Intitule"),json_data.getString("CT_Num"),json_data.getString("CG_NumPrinc"),json_data.getInt("n_CatTarif"),json_data.getInt("n_CatCompta")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return lcient;
    }


    public static Parametre enregistrementServeur(String user,String mdp){
        JSONObject json = null;
        ArrayList<Caisse> c=null;
        if(user.equals("borice") && mdp.equals("borice")){
        //try{
            c=listeCaisseServeur();
           // json = new JSONObject(msgToServer("caisse/1"));
           // JSONArray jArray = json.getJSONArray("data");
            //for(int i=0; i<jArray.length(); i++){
              //  JSONObject json_data = jArray.getJSONObject(i);
            //    c = new Caisse(json_data.getString("JO_Num"),json_data.getString("CA_Intitule"),json_data.getInt("CA_No"),json_data.getInt("CO_NoCaissier"));
          //  }
        //} catch (JSONException e) {
        //    e.printStackTrace();
        //}

        }
        return new Parametre(84,"42DWOKAMFOGUEALBA",19,1,"5210","11WO00001","LT 123 EB","borice","borice",c.get(0));
    }

    public static ArrayList<Client> listeClientServeur(String param){
        JSONObject json = null;
        ArrayList<Client> ldep=null;
        try {
//            json = new JSONObject(getJsonFromServer("http://genzy.esy.es/client.html"));
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/clients?op=" + param));
            JSONArray jArray = json.getJSONArray("data");
            ldep= new ArrayList<Client>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                ldep.add(new Client(json_data.getString("CT_Intitule"),json_data.getString("CT_Num"),json_data.getString("CG_NumPrinc"),json_data.getInt("n_CatTarif"),json_data.getInt("n_CatCompta")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ldep;
    }

    public static ArrayList<ArticleServeur> listeArticleServeur(){
        JSONObject json = null;
        ArrayList<ArticleServeur> lart=null;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/getAllArticle"));
            JSONArray jArray = json.getJSONArray("data");
            lart= new ArrayList<ArticleServeur>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new ArticleServeur(json_data.getInt("AR_Ref"),json_data.getString("AR_Design"),json_data.getDouble("AR_PrixAch"),json_data.getDouble("taxe1"),json_data.getDouble("taxe2"),json_data.getDouble("taxe3")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static int insertentete(String ticket, String clientComptoir, String vendeur, String depot,
                                    String lieulivraison, String catCompta, String cCaisse,
                                    String cCaissier, String numCG, String heure){
        JSONObject json;
        int id=0;
        try {
            String res = "insert_entete/" + ticket + "/" + clientComptoir + "/" + vendeur + "/" + depot + "/" + lieulivraison + "/" + catCompta + "/" + cCaisse + "/" + cCaissier + "/" + numCG + "/" + heure;
            System.out.println(res);
            json = new JSONObject(msgToServer(res));
            JSONArray jArray = json.getJSONArray("data");
            for (int i = 0; i < jArray.length(); i++) {
                JSONObject json_data = jArray.getJSONObject(i);
                id = json_data.getInt("Id_entete");
            }
        }catch (JSONException e){

        }
        return id;
    }

    public static int insererLigne(String article, String qte, String qteColisee, String designation, String pu) {
        JSONObject json;
        int id = 0;
        try {
            json = new JSONObject(msgToServer("insert_ligne/" + article + "/" + qte + "/" + qteColisee + "/" + designation + "/" + pu));
            JSONArray jArray = json.getJSONArray("data");
            for (int i = 0; i < jArray.length(); i++) {
                JSONObject json_data = jArray.getJSONObject(i);
                id = json_data.getInt("Id_ligne");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return id;
    }

    public static int ajoutLigneServeur(String no_fac,String ref_fac,int no_ligne,int dl_qte,int dl_remise){
        JSONObject json = null;
        int qte=0;
        try {
            String res = "http://192.168.1.14:8082/api/addDocligne?DO_Piece=" + no_fac + "&AR_Ref=" + ref_fac + "&ref=" + ref_fac + "&DL_Ligne=" + no_ligne+"&DL_Qte=" + dl_qte+"&DL_Remise=" + dl_remise;
            System.out.println(res);
            json = new JSONObject(getJsonFromServer(res));
            /*JSONArray jArray = json.getJSONArray("data");
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                qte = json_data.getInt("AS_QteSto");
            }*/
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return qte;
    }

    public static void supprimerEnetete(int id){
        msgToServer("delete_entete/"+id);
    }

    public static ArrayList<String> listeArticleServeurTexte(){
        ArrayList<String> lart= new ArrayList<String>();
        ArrayList<ArticleServeur> art =listeArticleServeur();
        for(int i=0;i<art.size();i++)
            lart.add(art.get(i).getAr_design());
        return lart;
    }

    public static ArrayList<String> listeDepotServeurTexte(){
        ArrayList<String> ldep= new ArrayList<String>();
        ArrayList<Depot> dep =listeDepotServeur();
        for(int i=0;i<dep.size();i++)
            ldep.add(dep.get(i).getNom());
        return ldep;
    }

    public static ArrayList<Affaire> listeAffaireServeur(){
        JSONObject json = null;
        ArrayList<Affaire> lart=null;
        try {
            json = new JSONObject(getJsonFromServer("http://genzy.esy.es/affaire.html"));
//            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/affaire"));
            JSONArray jArray = json.getJSONArray("data");
            lart= new ArrayList<Affaire>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new Affaire(json_data.getInt("CA_Num"),json_data.getString("CA_Intitule"),json_data.getInt("n_Analytique")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static ArrayList<String> listeAffaireTexte(){
        ArrayList<String> ldep= new ArrayList<String>();
        ArrayList<Affaire> dep =listeAffaireServeur();
        for(int i=0;i<dep.size();i++)
            ldep.add(dep.get(i).getCa_intitule());
        return ldep;
    }

    public static ArrayList<Vehicule> listeVehiculeServeur(){
        JSONObject json = null;
        ArrayList<Vehicule> lart=null;
        try {
            json = new JSONObject(getJsonFromServer("http://genzy.esy.es/vehicule.html"));
//            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/vehicule"));
            JSONArray jArray = json.getJSONArray("data");
            lart= new ArrayList<Vehicule>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new Vehicule(json_data.getString("CA_Num"),json_data.getString("CA_Intitule"),json_data.getInt("n_Analytique")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static ArrayList<String> listeVehiculeTexte(){
        ArrayList<String> ldep= new ArrayList<String>();
        ArrayList<Vehicule> dep =listeVehiculeServeur();
        for(int i=0;i<dep.size();i++)
            ldep.add(dep.get(i).getCa_intitule());
        return ldep;
    }
    public static ArrayList<ArticleServeur> listePrixProduitClient(String ref,String cat_compta,String cat_tarif){
        JSONObject json = null;
        ArrayList<ArticleServeur> lart=null;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/getPrixClient?AR_Ref="+ref+"&N_CatTarif="+cat_tarif+"&N_CatCompta="+cat_compta));
            //json = new JSONObject(getJsonFromServer("http://genzy.esy.es/article.html"));
            JSONArray jArray = json.getJSONArray("data");
            lart= new ArrayList<ArticleServeur>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new ArticleServeur(json_data.getInt("AR_Ref"),json_data.getString("AR_Design"),json_data.getDouble("AR_PrixAch"),json_data.getDouble("taxe1"),json_data.getDouble("taxe2"),json_data.getDouble("taxe3")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static ArrayList<Caisse> listeCaisseServeur(){
        JSONObject json = null;
        ArrayList<Caisse> lart=null;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/caisse"));
            JSONArray jArray = json.getJSONArray("data");
            lart= new ArrayList<Caisse>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new Caisse(json_data.getString("JO_Num"),json_data.getString("CA_Intitule"),json_data.getInt("CA_No"),json_data.getInt("CO_NoCaissier")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static double articleDisponibleServeur(int ref_art,int depot){
        JSONObject json = null;
        double qte=0;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/isStock?AR_Ref="+ref_art+"&DE_No="+depot));
            return json.getJSONObject("data").getDouble("AS_QteSto");
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return qte;
    }

    public static int ajoutEnteteServeur(int co_no,String ct_num,String ref_fac,String reg){
        JSONObject json = null;
        int qte=0;
        try {
            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/addDocentete?CO_No="+co_no+"&CT_Num="+ct_num+"&ref="+ref_fac+"&N_Reglement="+reg));
            JSONArray jArray = json.getJSONArray("data");
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                qte = json_data.getInt("AS_QteSto");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return qte;
    }



    public static ArrayList<String> listeCaisseServeurTexte(){
        ArrayList<String> ldep= new ArrayList<String>();
        ArrayList<Caisse> dep =listeCaisseServeur();
        for(int i=0;i<dep.size();i++)
            ldep.add(dep.get(i).getCa_intitule());
        return ldep;
    }

    public static ArrayList<Souche> listeSoucheServeur(){
        JSONObject json = null;
        ArrayList<Souche> lart=null;
        try {
//            json = new JSONObject(getJsonFromServer("http://192.168.1.14:8082/api/souche"));
            json = new JSONObject(getJsonFromServer("http://genzy.esy.es/souche.html"));
            JSONArray jArray = json.getJSONArray("data");
            lart= new ArrayList<Souche>();
            for(int i=0; i<jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                lart.add(new Souche(json_data.getString("JO_Num"),json_data.getString("JO_NumSituation"),json_data.getString("s_Intitule"),json_data.getInt("s_Valide"),json_data.getInt("cbIndice"),json_data.getInt("cbMarq")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lart;
    }

    public static ArrayList<String> listeSoucheServeurTexte(){
        ArrayList<String> ldep= new ArrayList<String>();
        ArrayList<Souche> dep =listeSoucheServeur();
        for(int i=0;i<dep.size();i++)
            ldep.add(dep.get(i).getS_intitule());
        return ldep;
    }


}
