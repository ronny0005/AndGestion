package com.example.tron.andgestion.bddlocal.facture;

import com.example.tron.andgestion.bddlocal.article.ArticleServeur;
import com.example.tron.andgestion.bddlocal.client.Client;
import com.example.tron.andgestion.bddlocal.fonction.outils;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by T.Ron on 18/03/2016.
 */
public class Facture implements Serializable {
    private int id;
    private String ref;
    private Client id_client;
    private int id_depot;
    private ArrayList<ArticleServeur> liste_article;
    private ArrayList<Integer> position_article;

    public Facture(String ref, Client id_client, int id_depot) {
        this.ref = ref;
        this.id_client = id_client;
        this.id_depot = id_depot;
        this.liste_article= outils.listeArticleServeur();
        this.position_article= new  ArrayList<Integer>();
    }

    public ArrayList<Integer> getPosition_article() {
        return position_article;
    }

    public void setPosition_article(ArrayList<Integer> position_article) {
        this.position_article = position_article;
    }

    public int getId() {
        return id;
    }

    public Facture(String ref) {
        this.ref = ref;
        this.liste_article= outils.listeArticleServeur();
        this.position_article= new  ArrayList<Integer>();
    }

    public Facture() {
        this.liste_article= new  ArrayList<ArticleServeur>();
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public Client getId_client() {
        return id_client;
    }

    public void setId_client(Client id_client) {
        this.id_client = id_client;
    }

    public int getId_depot() {
        return id_depot;
    }

    public void setId_depot(int id_depot) {
        this.id_depot = id_depot;
    }

    public ArrayList<ArticleServeur> getListe_article() {
        return liste_article;
    }

    public void setListe_article(ArrayList<ArticleServeur> liste_article) {
        this.liste_article = liste_article;
    }
}
